import Foundation

class ___FILEBASENAMEASIDENTIFIER___ {

    private let model: ___VARIABLE_productName:identifier___

    init(withModel model: ___VARIABLE_productName:identifier___) {
        self.model = model
    }
}