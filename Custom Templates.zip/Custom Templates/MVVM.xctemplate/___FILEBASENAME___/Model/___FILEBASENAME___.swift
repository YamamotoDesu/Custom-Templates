
import Foundation

class ___FILEBASENAMEASIDENTIFIER___ {
  
}