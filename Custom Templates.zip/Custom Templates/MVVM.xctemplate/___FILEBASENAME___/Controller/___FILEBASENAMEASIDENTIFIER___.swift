import UIKit

class ___FILEBASENAMEASIDENTIFIER___: UIViewController {
    
    let viewModel: ___VARIABLE_productName___ViewModel
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        viewModel = ___VARIABLE_productName___ViewModel(withModel: ___VARIABLE_productName___())
    }
}